import React, { useState } from 'react';

function Items() {
  const [searchTerm, setSearchTerm] = useState('');
  const [items, setItems] = useState([]);

  // Mock data for items
  const mockItems = [
    { id: 1, name: 'Item 1', description: 'Description 1', price: 10 },
    { id: 2, name: 'Item 2', description: 'Description 2', price: 20 },
    { id: 3, name: 'Item 3', description: 'Description 3', price: 30 },
  ];

  // Function to handle search
  const handleSearch = () => {
    // Code to search items based on searchTerm
    const filteredItems = mockItems.filter((item) =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    // Populate items state with search results
    setItems(filteredItems);
  };

  return (
    <div className="container">
      <h2>Items</h2>
      <input
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
        placeholder="Search items..."
      />
      <button onClick={handleSearch}>Search</button>
      <ul>
        {/* Display items here */}
        {items.map((item) => (
          <li key={item.id}>
            <h3>{item.name}</h3>
            <p>{item.description}</p>
            <p>Price: ${item.price}</p>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Items;