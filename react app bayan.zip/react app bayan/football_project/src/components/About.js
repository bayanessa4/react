import React from 'react';

function About() {
  return (
    <div className="container">
      <h2>About Us</h2>
      <p>This is a brief description about myself and the reason for choosing the content displayed on this site.</p>
    </div>
  );
}

export default About;